function [vco_sq,prev]=vco_phase_integrator(sw1,prev,mismatch)

format long;
global  t Q M



%Initializing Variables to make program run fast

vco_sin=zeros(1,Q);
vco_sq=vco_sin;

p=prev(1);
%VCO operation between 2 sampling edges
for j=1:M
    %frequency corresponsing to amplitude
    f=vco_v2f(sw1(j),mismatch);
    for l=1:Q  


            
            if(l==1)
              p = (p + (2*pi/Q))/(2*pi*f);
              vco_sin(l)=sin(2*pi*f*(t+p)) ;
              p=(2*pi*f*(t+p));
            else
                p = p + (2*pi/Q);
                vco_sin(l)=sin(p);
            end
        
        
    

            %Convert sin to square 
                if(vco_sin(l) >= 0)
                    vco_sq(l) =1;
                else
                    vco_sq(l)=0;
                end
     
    
        %two previous sine values saved for next sampling time.
     

    end      
    prev(2)=prev(1);
    prev(1)=p;
end    

%vco_sq now has the last value at sample. 
   

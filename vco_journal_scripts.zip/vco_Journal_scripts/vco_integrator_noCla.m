
function [vco_out,dac_out1]=vco_integrator_noCla(sw1,sw2,m1,m2)

global Q M ;
j=2;

vco_out=zeros(1,floor(length(sw1)/M));
dac_out1=zeros(1,floor(length(sw1)/M));
dac_out2=zeros(1,floor(length(sw1)/M));
inp=zeros(1,floor(length(sw1)/M));

prev1=[0 0];
prev2=[0 0];



for i=M:M:length(sw1)-M

    inp(i:i+M) = ((sw1(i:i+M)+ (dac_out1(j-1)*0.3 * 2 /Q)))/2;           % for +sin
    inp1=inp(i:i+M);
    inp2 = (( sw2(i:i+M)+  dac_out2(j-1) * 0.3 * 2 /Q))/2;     % for -sin
    [vco_out(j),dac_out1(j),dac_out2(j),prev1,prev2]=vco_pd_integrator_noCla(inp1,inp2,prev1,prev2,m1,m2);
    j=j+1;
    

end


    function [f] = vco_v2f(x,mismatch)
	global  mism;
     if(mismatch ==1)
         
       p1 = -1.2924e+008;
       p2 =  9.0192e+007 ;
       p3 = -1.2084e+007;
       p4 =  4.668e+005;
       p5 =   2.784e+004 ;
       f = p1*x^4 + p2*x^3 + p3*x^2 + p4*x + p5;
     end 
     if(mismatch==2)  
       p1 = -1.2924e+008;
       p2 =  9.0192e+007 ;
       p3 = -1.2084e+007;
       p4 =  4.668e+005;
       p5 =   2.784e+004 ;
       f = p1*x^4 + p2*x^3 + p3*x^2 + p4*x + p5;
       f = f*(1+mism);
     end
      
       
      

clc
clear
format long
global Q M t  pattern  dac_element ;

% Quantizer level to 27
Q=54;

% design variables
fftLength = 2^18;
fs=1280000; % sampling frequency
f1=2.03125e+03;  %signal frequency
ts = 1/fs;   % sampling time

% internal variables
M =218;
pattern=zeros(1,Q/2);
t = ts/M;
N= 13*fftLength/2^13;

x=(ts:ts:N/f1);
y=(0:t:(N+0.1)/f1);

% differential sinusoids
sw1 = 0.15 +0.13*sin(2*pi*f1*y);
sw2 = 0.15 -0.13*sin(2*pi*f1*y);


% non-linear dac
dac_element = normrnd(1,0.034,1,Q/2);

% vco-integrator based first order delta sigma modulator
[vco_out1,dac_out1] = vco_integrator_cla(sw1,sw2,1,1);

% without cla
[vco_out2,dac_out2] = vco_integrator_noCla(sw1,sw2,1,1);

% fft with cla case
vco_out1=vco_out1(end-fftLength+1:end);
vco_out1 = vco_out1 - mean(vco_out1);
vco_out1 = vco_out1.*blackmanharris(length(vco_out1)).';
newFFT1=fft(vco_out1',fftLength)/fftLength;

% fft without cla case
vco_out2=vco_out2(end-fftLength+1:end);
vco_out2 = vco_out2 - mean(vco_out2);
vco_out2 = vco_out2.*blackmanharris(length(vco_out2)).';
newFFT2=fft(vco_out2',fftLength)/fftLength;

  


freq=fs/2*linspace(0,1,fftLength/2);
val1=20*log10(abs(newFFT1(1:fftLength/2)));
plot(freq(1:end),val1(1:end),'r');
grid on

set(gca,'XScale','log')
xlim([5,640000]);
ylim([-140,0]);

hold;

freq=fs/2*linspace(0,1,fftLength/2);
val1=20*log10(abs(newFFT2(1:fftLength/2)));
plot(freq(1:end),val1(1:end),'b');
grid on

set(gca,'XScale','log')
xlim([5,640000]);
ylim([-140,0]);     
     


%clear;
% This module operates 2 vcos as integrator using psuedo differntial xor


function [vco_out,dac_out1,dac_out2,prev1,prev2]=vco_pd_integrator_cla(sw1,sw2,prev1,prev2,m1,m2)

%variables 
global dac_element pattern;




        [vco_sq1,prev1]=vco_phase_integrator (sw1 ,prev1 ,m1);
        [vco_sq2,prev2]=vco_phase_integrator (sw2 ,prev2 ,m2);

       vco_out=0;
       dac_out1=0;
       dac_out2=0;

        for i=1:length(vco_sq1)/2
            pattern(i)= (xor(vco_sq1(i),vco_sq2(i)));
            vco_out=vco_out+(xor(vco_sq1(i),vco_sq2(i)));
            dac_out1=dac_out1 + dac_element(i)*(xor(vco_sq1(i),vco_sq2(i)));
            dac_out2=dac_out2 + dac_element(i)*(~xor(vco_sq1(i),vco_sq2(i)));
            
        end

                    

end
           

        

       



clc
clear
format long
global Q M t  mism pattern avgInp1 avgInp2 dac_element ;

% Quantizer level to 27
Q=54;


% design variables
fftLength = 2^14;
fs=1280000; % sampling frequency
f1=2.03125e+03;  %signal frequency
ts = 1/fs;   % sampling time

% internal variables
M =218;
pattern=zeros(1,Q/2);
t = ts/M;
N= 13*fftLength/2^13;
avgInp1=0;
avgInp2=0;


x=(ts:ts:N/f1);
y=(0:t:(N+0.1)/f1);

% differential sinusoids
sw1 = 0.15 +0.13*sin(2*pi*f1*y);
sw2 = 0.15 -0.13*sin(2*pi*f1*y);


% linear dac
dac_element = normrnd(1,0,1,Q/2);


k=0;

for mism = -0.2:0.05:0.2

    k=k+1;
% vco-integrator based first order delta sigma modulator
    [vco_out,dac_out] = vco_integrator_kvco(sw1,sw2,2,1);

    avgOutput(k) = mean(vco_out);
    avgVCOInp1(k)= avgInp1;
    avgVCOInp2(k)= avgInp2;
    
end

plot(avgOutput);
hold;
plot(avgVCOInp1);
plot(avgVCOInp2);



     

